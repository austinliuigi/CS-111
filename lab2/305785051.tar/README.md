# You Spin Me Round Robin

In this lab, we implement the round robin scheduling algorithm.

## Building

```shell
make
```

## Running

```shell
./rr <process_file> <quantum_length>
```

## Cleaning up

```shell
make clean
```
